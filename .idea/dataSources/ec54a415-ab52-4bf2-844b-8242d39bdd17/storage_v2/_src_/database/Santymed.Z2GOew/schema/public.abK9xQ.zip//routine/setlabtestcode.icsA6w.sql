create function setlabtestcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"LabTest"', 'LabTest');
	return null;
End
$$;

alter function setlabtestcode() owner to postgres;

