create function updateaccountbalanceondelete() returns trigger
    language plpgsql
as
$$
DECLARE
	payment_type integer;

BEGIN
	payment_type := (select "Type" from "PaymentType" where "OID" = old."Type");
	update "Account" set "Balance" = "Balance" - (old."Amount" * case when payment_type = 0 then -1 else 1 end), "OptimisticLockField" = "OptimisticLockField" + 1
		where "OID" = old."Account";
	return null;
End
$$;

alter function updateaccountbalanceondelete() owner to postgres;

