create function updateaccountbalanceoninsert() returns trigger
    language plpgsql
as
$$
DECLARE
	payment_type integer;

BEGIN
	payment_type := (select "Type" from "PaymentType" where "OID" = new."Type");
	update "Account" set "Balance" = "Balance" + (new."Amount" * case when payment_type = 0 then -1 else 1 end), "OptimisticLockField" = "OptimisticLockField" + 1
		where "OID" = new."Account";
	return null;
End
$$;

alter function updateaccountbalanceoninsert() owner to postgres;

