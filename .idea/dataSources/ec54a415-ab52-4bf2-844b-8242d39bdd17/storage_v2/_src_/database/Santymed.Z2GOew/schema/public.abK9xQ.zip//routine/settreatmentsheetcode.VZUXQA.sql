create function settreatmentsheetcode() returns trigger
    language plpgsql
as
$$


BEGIN
	PERFORM setnextcode(new."OID", '"TreatmentSheet"', 'TreatmentSheet');
	return null;
End
$$;

alter function settreatmentsheetcode() owner to postgres;

