create function setradiotestcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"RadioTest"', 'RadioTest');
	return null;
End
$$;

alter function setradiotestcode() owner to postgres;

