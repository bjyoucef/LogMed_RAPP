create function sec_usermustlogin() returns boolean
    language plpgsql
as
$$DECLARE usersCount integer;
DECLARE userPassword text;

BEGIN
usersCount = (SELECT COUNT("OID") FROM "User");

IF(usersCount > 1) THEN
	RETURN true;
END IF;

userPassword = (SELECT "Password" FROM "User" LIMIT 1);

IF(userPassword != '+N59qxl8fgjJZG2CjaMS8w==') THEN
	RETURN true;
END IF;

RETURN false;

END $$;

alter function sec_usermustlogin() owner to postgres;

