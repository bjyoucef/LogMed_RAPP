create function rep_getreports(p_context character varying)
    returns TABLE(oid integer, label character varying, shortcut character varying)
    language plpgsql
as
$$

BEGIN
   RETURN QUERY select r."OID", r."Label", r."Shortcut" from "ReportContext" rc
inner join "Report" r on rc."Report" = r."OID"
inner join "Context" ct on rc."Context" = ct."OID" 
where ct."Name" = p_context and (r."Hidden" <> true or r."Hidden" is null)
order by r."Label";

END $$;

alter function rep_getreports(varchar) owner to postgres;

