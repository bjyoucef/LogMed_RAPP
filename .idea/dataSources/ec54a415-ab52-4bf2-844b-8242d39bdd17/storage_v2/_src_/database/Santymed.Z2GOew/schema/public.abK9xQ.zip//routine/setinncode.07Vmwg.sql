create function setinncode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Inn"', 'Inn');
	return null;
End
$$;

alter function setinncode() owner to postgres;

