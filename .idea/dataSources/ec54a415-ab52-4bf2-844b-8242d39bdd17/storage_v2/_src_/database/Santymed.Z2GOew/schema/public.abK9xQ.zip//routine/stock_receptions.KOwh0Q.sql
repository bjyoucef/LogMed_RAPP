create function stock_receptions("startDate" timestamp with time zone, "endDate" timestamp with time zone)
    returns TABLE(oid integer, label character varying, quantity double precision)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY
	SELECT it."OID", it."Label", sum(dd."Quantity") AS quantity
	FROM "DocumentDetail" dd
		LEFT JOIN "Document" d ON dd."Document" = d."OID"
		LEFT JOIN "DocumentType" dt ON d."Type" = dt."OID"
		LEFT JOIN "Batch" b ON dd."Batch" = b."OID"
		LEFT JOIN "Item" it ON b."Item" = it."OID"
  	WHERE it."Type" = 0 AND dt."BaseType" = 1 and (d."Status" = 2 or d."Status" = 3) and
		d."Date" >= "startDate" and d."Date" < "endDate"
   	GROUP BY it."OID";
END;
$$;

alter function stock_receptions(timestamp with time zone, timestamp with time zone) owner to postgres;

