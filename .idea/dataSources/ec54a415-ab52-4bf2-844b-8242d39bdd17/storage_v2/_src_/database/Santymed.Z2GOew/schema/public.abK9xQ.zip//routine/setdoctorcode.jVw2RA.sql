create function setdoctorcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Doctor"', 'Doctor');
	return null;
End
$$;

alter function setdoctorcode() owner to postgres;

