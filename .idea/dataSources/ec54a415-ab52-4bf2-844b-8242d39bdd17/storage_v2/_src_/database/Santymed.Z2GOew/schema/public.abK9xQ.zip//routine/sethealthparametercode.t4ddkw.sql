create function sethealthparametercode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"HealthParameter"', 'HealthParameter');
	return null;
End
$$;

alter function sethealthparametercode() owner to postgres;

