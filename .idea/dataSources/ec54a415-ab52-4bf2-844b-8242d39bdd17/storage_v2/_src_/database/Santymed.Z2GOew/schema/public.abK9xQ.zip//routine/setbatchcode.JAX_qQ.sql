create function setbatchcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Batch"', 'Batch');
	return null;
End
$$;

alter function setbatchcode() owner to postgres;

