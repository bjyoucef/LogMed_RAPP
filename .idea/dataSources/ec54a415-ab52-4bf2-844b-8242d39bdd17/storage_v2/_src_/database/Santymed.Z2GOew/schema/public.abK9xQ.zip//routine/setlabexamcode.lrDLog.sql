create function setlabexamcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"LabExam"', 'LabExam');
	return null;
End
$$;

alter function setlabexamcode() owner to postgres;

