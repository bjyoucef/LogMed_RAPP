create function setechographycode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"EchographyBase"', 'Echography');
	return null;
End
$$;

alter function setechographycode() owner to postgres;

