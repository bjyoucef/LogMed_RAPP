create function setconsultationcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Consultation"', 'Consultation');
	return null;
End
$$;

alter function setconsultationcode() owner to postgres;

