create function sethysteroscopycode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Hysteroscopy"', 'Hysteroscopy');
	return null;
End
$$;

alter function sethysteroscopycode() owner to postgres;

