create function stock_quantitydate(date timestamp with time zone)
    returns TABLE(oid integer, label character varying, quantity double precision)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY
	SELECT it."OID" as oid, it."Label", sum(dd."Quantity" * dt."Factor") AS quantity
	FROM "DocumentDetail" dd
		LEFT JOIN "Document" d ON dd."Document" = d."OID"
		LEFT JOIN "DocumentType" dt ON d."Type" = dt."OID"
		LEFT JOIN "Batch" b ON dd."Batch" = b."OID"
		LEFT JOIN "Item" it ON b."Item" = it."OID"
	WHERE it."Type" = 0 AND d."Date" < date and (d."Status" = 2 or d."Status" = 3) and
		(dt."BaseType" = 1 or dt."BaseType" = 2 or dt."BaseType" = 21 or dt."BaseType" = 22)
	GROUP BY it."OID";
END;
$$;

alter function stock_quantitydate(timestamp with time zone) owner to postgres;

