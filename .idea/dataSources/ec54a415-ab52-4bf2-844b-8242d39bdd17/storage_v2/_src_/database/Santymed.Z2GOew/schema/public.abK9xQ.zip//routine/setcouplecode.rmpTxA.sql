create function setcouplecode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Couple"', 'Couple');
	return null;
End
$$;

alter function setcouplecode() owner to postgres;

