create function setprescriptioncode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Prescription"', 'Prescription');
	return null;
End
$$;

alter function setprescriptioncode() owner to postgres;

