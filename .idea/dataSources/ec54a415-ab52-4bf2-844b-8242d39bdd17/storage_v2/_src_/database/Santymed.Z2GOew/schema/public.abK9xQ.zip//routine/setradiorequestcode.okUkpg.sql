create function setradiorequestcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"RadioRequest"', 'RadioRequest');
	return null;
End
$$;

alter function setradiorequestcode() owner to postgres;

