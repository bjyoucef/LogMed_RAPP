create function setnextcode(p_oid integer, p_tablename character varying, p_context character varying) returns character varying
    language plpgsql
as
$$

DECLARE
	isactive boolean;
	nextnumber integer;
	charsnumber integer;
	pattern character varying;
	code character varying;

BEGIN
	-- Lock the row table for read and write,
	-- so that no two records have same number if insert are at same time
	select "Counter", "CounterSize", "Pattern", "IsActive"
	into nextnumber, charsnumber, pattern, isactive 
	from "CodingRule" 
	where "Context" = p_context 
	FOR UPDATE;
	
	IF(isactive = false) THEN
		return null;
	END IF;
	
	code := replace(pattern, '{C}', LPAD(nextnumber::text, charsnumber, '0'));
	code := replace(code, '{y}', to_char(now(), 'YY'));
	code := replace(code, '{Y}', to_char(now(), 'YYYY'));
	code := replace(code, '{M}', to_char(now(), 'MM'));
	code := replace(code, '{d}', to_char(now(), 'DD'));
			
	IF(code is null) THEN
		return null;
	END IF;
	
	update "CodingRule" set "Counter" = "Counter" + 1 where "Context" = p_context;
	
	EXECUTE 
		'update ' 
		|| p_tablename
		|| ' set "OptimisticLockField" = "OptimisticLockField" + 1, "Code" = ''' 
		|| code 
		|| ''' where "OID" = ' 
		|| p_oid;
		
	return code;
	
END;
$$;

alter function setnextcode(integer, varchar, varchar) owner to postgres;

