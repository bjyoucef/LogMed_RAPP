create function setinsuranceagencycode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"InsuranceAgency"', 'InsuranceAgency');
	return null;
End
$$;

alter function setinsuranceagencycode() owner to postgres;

