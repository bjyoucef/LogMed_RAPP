create function setsurgerycode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Work"', 'Work');
	return null;
End
$$;

alter function setsurgerycode() owner to postgres;

