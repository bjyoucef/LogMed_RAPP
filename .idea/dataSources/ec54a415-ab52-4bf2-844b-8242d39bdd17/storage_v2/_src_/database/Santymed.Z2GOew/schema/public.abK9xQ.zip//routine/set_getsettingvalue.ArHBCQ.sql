create function set_getsettingvalue("userOid" integer, "folderOid" integer, code text) returns text
    language plpgsql
as
$$
DECLARE settingScope integer;
DECLARE settingValue text = '';
BEGIN
	settingScope = (SELECT "Setting"."Scope" FROM public."Setting" WHERE "Setting"."Code" = "code");
	
	-- 0 : User Setting
	IF( settingScope = 0) THEN
		RETURN (SELECT "SettingValue"."Value" FROM public."Setting", public."SettingValue" WHERE "SettingValue"."Setting" = "Setting"."OID" AND "Setting"."Code" = "code" AND "SettingValue"."User" = "userOid");
	END IF;
	
	-- 1 : Folder Setting
	IF( settingScope = 1) THEN
		RETURN (SELECT "SettingValue"."Value" FROM public."Setting", public."SettingValue" WHERE "SettingValue"."Setting" = "Setting"."OID" AND "Setting"."Code" = "code" AND "SettingValue"."Folder" = "folderOid");
	END IF;
		
	-- 2 : Global Setting
	IF( settingScope = 2) THEN
		RETURN (SELECT "SettingValue"."Value" FROM public."Setting", public."SettingValue" WHERE "SettingValue"."Setting" = "Setting"."OID" AND "Setting"."Code" = "code");
	END IF;
		
	RETURN null;
END;$$;

alter function set_getsettingvalue(integer, integer, text) owner to postgres;

