create function sethospitalizationcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Hospitalization"', 'Hospitalization');
	return null;
End
$$;

alter function sethospitalizationcode() owner to postgres;

