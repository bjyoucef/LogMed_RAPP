create function setmedicalmailcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"MedicalMail"', 'MedicalMail');
	return null;
End
$$;

alter function setmedicalmailcode() owner to postgres;

