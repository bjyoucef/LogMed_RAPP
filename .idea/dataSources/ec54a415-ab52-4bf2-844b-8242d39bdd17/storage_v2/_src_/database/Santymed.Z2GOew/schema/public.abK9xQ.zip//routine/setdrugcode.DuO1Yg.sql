create function setdrugcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Drug"', 'Drug');
	return null;
End
$$;

alter function setdrugcode() owner to postgres;

