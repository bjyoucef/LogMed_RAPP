create function getpatientbalance(p_patientoid integer) returns numeric
    language plpgsql
as
$$
DECLARE
	thirdpartyoid integer;
	totalmedicalacts numeric(28,8);
	totallabexams numeric(28,8);
	totalhospitalizations numeric(28,8);
	totalsurgeries numeric(28,8);
	totalradiographies numeric(28,8);
	totalnursings numeric(28,8);
	totalrehabilitations numeric(28,8);
	totalinvoices numeric(28,8);
	totalpayments numeric(28,8);
	balance numeric(28,8);

BEGIN
	thirdpartyoid := (select "ThirdParty" from "Patient" where "OID" = p_patientoid);
	totalmedicalacts := (select sum(coalesce("PatientPart", 0)) from "MedicalAct" where "Patient" = p_patientoid and "Invoice" is null);
	totallabexams := (select sum(coalesce("PatientPart", 0)) from "LabExam" where "Patient" = p_patientoid and "Status" > 0 and "Invoice" is null);
	totalhospitalizations := (select sum(coalesce("PatientPart", 0)) from "Hospitalization" where "Patient" = p_patientoid and "Invoice" is null);
	totalsurgeries := (select sum(coalesce("PatientPart", 0)) from "Work" where "Patient" = p_patientoid and "Invoice" is null);
	totalradiographies := (select sum(coalesce("PatientPart", 0)) from "RadioRequest" where "Patient" = p_patientoid and ("Status" > 1 or "Status" = 2) and "Invoice" is null);
	totalnursings := (select sum(coalesce("PatientPart", 0)) from "Nursing" where "Patient" = p_patientoid and ("Status" = 1 or "Status" = 2) and "Invoice" is null);
	totalrehabilitations := (select sum(coalesce("PatientPart", 0)) from "Rehabilitation" where "Patient" = p_patientoid and ("Status" = 1 or "Status" = 2) and "Invoice" is null);
	totalinvoices := (select sum(d."AmountAti") from "Document" d left join "DocumentType" dt on d."Type" = dt."OID" 
					  where d."ThirdParty" = thirdpartyoid and dt."BaseType" = 14);
	totalpayments := (select sum("Amount"* (case when pt."Type" = 1 then 1 else -1 end)) 
					from "Payment" p left join "PaymentType" pt on p."Type" = pt."OID"
					where "ThirdParty" = thirdpartyoid);
	
	balance = coalesce(totalmedicalacts, 0) + coalesce(totallabexams, 0) + 
		coalesce(totalhospitalizations, 0) + coalesce(totalsurgeries, 0) + 
		coalesce(totalradiographies, 0) + 
		coalesce(totalnursings, 0) + coalesce(totalrehabilitations, 0) + 
		coalesce(totalinvoices, 0) - coalesce(totalpayments, 0);
	
	return balance;
	
END;
$$;

alter function getpatientbalance(integer) owner to postgres;

