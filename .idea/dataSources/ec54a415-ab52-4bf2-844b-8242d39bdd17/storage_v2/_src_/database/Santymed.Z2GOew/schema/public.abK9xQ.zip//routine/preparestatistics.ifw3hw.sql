create function preparestatistics() returns void
    language sql
as
$$
-- stat_documents
delete from stat_documents;
insert into stat_documents (oid, date, documenttype, thirdparty, thirdpartytype, company, amountht, amountvat, amountati, payment, rest)
select d."OID" as oid, d."Date" as date, dt."BaseType" as documenttype, th."Name" as thirdparty, th."Type" as thirdpartyType, c."Label" as company, d."AmountHt" as amountht,
d."AmountVat" as amountvat, d."AmountAti" as amountati, d."Payment" as payment, d."AmountAti" - d."Payment" as rest
from "Document" d left join "ThirdParty" th on d."ThirdParty" = th."OID"
left join "DocumentType" dt on d."Type" = dt."OID"
left join "Company" c on d."Company" = c."OID"
where d."Status" = 2 or d."Status" = 3;

-- stat_diagnosis
delete from stat_diagnosis;
insert into stat_diagnosis (patientoid, consultationoid, gender, age, profession, category, department, diagnosis, date)
select p."OID" as patientoid, c."OID" as consultationoid, 
case when p."Gender" = 1 then 'Masculin' when p."Gender" = 2 then 'Féminin' else '-Non defini-'end as gender, 
extract (year from age(now(), p."BirthDate")) as age, p."Profession" as profession, 
cat."Label" as category, d."Label" as department, c."DiagnosisResult" as diagnosis, c."Date" as date
from "Consultation" c left join "Patient" p on c."Patient" = p."OID"
left join "PatientCategory" cat on p."Category" = cat."OID"
left join "ThirdParty" th on p."ThirdParty" = th."OID"
left join "City" cit on th."City" = cit."OID"
left join "Department" d on cit."Department" = d."OID"
where (c."DiagnosisResult" = '') is not true and length(c."DiagnosisResult") > 1;

-- stat_labexams
delete from stat_labexams;
insert into stat_labexams (oid, date, convention, amount, patientpart, insurancepart, payment, patientpayment, insurancepayment, rest, restpatient, restinsurance)
select l."OID" as oid, l."RequestDate" as date, a."Label" as convension, l."Amount" as amount, l."PatientPart" as patientpart, 
l."Amount" - l."PatientPart" as insurancepart, l."InsurancePayment" + l."PatientPayment" as payment, 
l."PatientPayment" as patientpayment, l."InsurancePayment" as insurancepayment, l."Amount" - (l."PatientPayment" + l."InsurancePayment") as rest,
l."PatientPart" - l."PatientPayment" as restpatient, (l."Amount" - l."PatientPart") - l."InsurancePayment" as restinsurance
from "LabExam" l left join "Patient" p on l."Patient" = p."OID"
left join "InsuranceAgency" a on p."PaymentCenter" = a."OID"
where l."Status" = 2 or l."Status" = 3;

-- stat_labtests
delete from stat_labtests;
insert into stat_labtests (detailoid, labtest, category, date)
select d."OID" as detailoid, t."Label" as labtest, c."Label" as category, l."RequestDate" as date
from "LabExamDetail" d left join "LabTest" t on d."LabTest" = t."OID"
left join "LabExam" l on d."LabExam" = l."OID"
left join "LabTestCategory" c on t."Category" = c."OID"
where d."LabTest" is not null and d."Parent" is null and (l."Status" = 2 or l."Status" = 3);

-- stat_medicalacts
delete from stat_medicalacts;
insert into stat_medicalacts (type, patient, date, amount, patientpart, patientpayment, insurancepayment, doctor, associateamount, associatepercent)
(select t."Label" as type, coalesce(p."LastName", '') || ' ' || coalesce(p."FirstName", '') as patient,
	a."StartDate" as date, a."Amount" as amount, a."PatientPart" as patientpart, a."PatientPayment" as patientpayment, a."InsurancePayment" as insurancepayment,
	coalesce(d."LastName", '') || ' ' || coalesce(d."FirstName", '') as doctor, 
	t."AssociateAmount" as associateamount, t."AssociatePercent" as associatepercent
from "MedicalAct" a 
	left join "MedicalActType" t on a."Type" = t."OID"
	left join "Doctor" d on a."Practitioner" = d."OID"
	left join "Patient" p on a."Patient" = p."OID");
	
-- stat_patients
delete from stat_patients;
insert into stat_patients (oid, createdon, gender, meansofcontact, bloodtype, profession, age, category, convention)
select p."OID" as oid, p."CreatedOn" as createdon, 
case when p."Gender" = 1 then 'Masculin' when p."Gender" = 2 then 'Féminin' else 'Non défini' end as gender, 
p."MeansOfContact" as meansofcontact,
p."BloodType" as bloodtype, p."Profession" as profession, extract (year from age(now(), p."BirthDate")) as age,
c."Label" as category, a."Label" as convention
from "Patient" p left join "PatientCategory" c on p."Category" = c."OID"
left join "InsuranceAgency" a on p."PaymentCenter" = a."OID";

-- stat_partnership
delete from stat_partnership;
-- 1. surgeries
insert into stat_partnership(type, date, doctor, patient, amount, partnership, partnershipvalue)
select coalesce(st."Label", 'Chirurgie') as type, s."Date",  d."LastName" || ' ' || d."FirstName" as doctor, 
p."LastName" || ' ' || p."FirstName" as patient, st."Amount" as amount, (dsp."Amount"/st."Amount") *100 as partnershippercent, dsp."Amount" as partnershipvalue
from "Work" s 
	left join "Doctor" d on s."Operator" = d."OID"
	left join "Patient" p on s."Patient" = p."OID"
	left join "SurgeryType" st on s."Type" = st."OID"
	left join "DoctorSurgeryPartnership" dsp on dsp."SurgeryType" = st."OID";
-- 2. lab exams
insert into stat_partnership (type, date, doctor, patient, amount, partnership, partnershipvalue)
select 'Analyses médicales' as type, s."RequestDate",  d."LastName" || ' ' || d."FirstName" as doctor, 
p."LastName" || ' ' || p."FirstName" as patient, s."Amount", d."LaboratoryPartnership", s."Amount" * (d."LaboratoryPartnership"/100) as partnershipvalue
from "LabExam" s 
	left join "Doctor" d on s."Doctor" = d."OID"
	left join "Patient" p on s."Patient" = p."OID"
where s."Status" >= 3;
-- 3. radio
insert into stat_partnership (type, date, doctor, patient, amount, partnership, partnershipvalue)
select t."Label", r."Date", dr."LastName" || ' ' || dr."FirstName" as doctor, p."LastName" || ' ' || p."FirstName" as patient,
t."Price" as amount, coalesce((pr."Amount" / t."Price")*100, 0) as partnershippercent,  coalesce(pr."Amount", 0) as partnershipvalue
from "RadioRequestDetail" d 
	left join "RadioRequest" r on d."RadioRequest" = r."OID"
	left join "RadioTest" t on d."RadioTest" = t."OID"
	left join "Doctor" dr on r."Doctor" = dr."OID"
	left join "Patient" p on r."Patient" = p."OID"
	left join "DoctorRadioExamPartnership" pr on pr."RadioTest" = t."OID" and pr."Doctor" = dr."OID"
where r."Status" = 2;
--4. medical acts
insert into stat_partnership (type, date, doctor, patient, amount, partnership, partnershipvalue)
select coalesce(t."Label", 'Acte médical'), m."StartDate", d."LastName" || ' ' || d."FirstName",
p."LastName" || ' ' || p."FirstName", m."Amount", dp."PartnershipValue" as partnership, m."Amount"*(dp."PartnershipValue"/100) as partnershipvalue
from "MedicalAct" m
	left join "MedicalActType" t on m."Type" = t."OID"
	left join "Patient" p on m."Patient" = p."OID"
	left join "Doctor" d on m."Practitioner" = d."OID"
	left join "DoctorMedicalActPartnership" dp on dp."Doctor" = d."OID";
	
-- CRM
delete from stat_prospects;
insert into stat_prospects (oid, categoryoid, category, gender, referraloid, referral, createdby, date, stageoid, stage, failedreasonoid, failedreason, issucces, isfailed)
select p."OID", pc."OID" as categoryoid, pc."Label" as category, p."Gender", pr."OID" as referraloid, pr."LastName" || pr."FirstName" as referral,  
p."CreatedBy", p."CreatedOn" as date, s."OID" as stageoid, s."Label" as stage, f."OID" as failedreasonoid, f."Label", s."IsAccepted", s."IsFailed"
from "Prospect" p 
	left join "ProspectCategory" pc on p."Category" = pc."OID"
	left join "Referral" pr on p."Referral" = pr."OID"
	left join "ProspectFaildReason" f on p."FailedReason" = f."OID"
	left join "ProspectStage" s on p."Stage" = s."OID";
$$;

alter function preparestatistics() owner to postgres;

