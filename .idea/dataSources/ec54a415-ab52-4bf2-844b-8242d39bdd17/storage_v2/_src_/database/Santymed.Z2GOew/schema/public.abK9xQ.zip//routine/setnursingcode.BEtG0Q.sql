create function setnursingcode() returns trigger
    language plpgsql
as
$$
BEGIN
	PERFORM setnextcode(new."OID", '"Nursing"', 'Nursing');
	return null;
End
$$;

alter function setnursingcode() owner to postgres;

