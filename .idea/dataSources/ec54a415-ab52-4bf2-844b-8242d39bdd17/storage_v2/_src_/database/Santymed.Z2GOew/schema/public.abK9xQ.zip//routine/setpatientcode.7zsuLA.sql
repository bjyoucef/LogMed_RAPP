create function setpatientcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Patient"', 'Patient');
	return null;
End
$$;

alter function setpatientcode() owner to postgres;

