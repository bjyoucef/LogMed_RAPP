create function setwaitingroomentrynumber() returns trigger
    language plpgsql
as
$$


DECLARE
	max_number integer;
	use_global_counter_str character varying;
	use_global_counter boolean default false;

BEGIN

	-- check if a global counter should be used
	use_global_counter_str := 
		(select "Value" 
		 from "SettingValue" sv left join "Setting" s on sv."Setting" = s."OID"
		 where s."Code" = 'WaitingRoomUseGlobalCounter');
		 
	 IF (use_global_counter_str is not null) THEN
	 	use_global_counter = cast(use_global_counter_str as boolean);
	END IF;

	-- get max number
	IF(use_global_counter) THEN
		 select coalesce(max("Number"), 0) into max_number 
		 from "WaitingRoomEntry" 
		 where "Period" = new."Period";
	ELSE
		select "Counter" into max_number
		from "WaitingRoom" 
		where "OID" = new."WaitingRoom"
		for update;
	END IF;

	-- update Waiting room counter
	update "WaitingRoom"
	set "Counter" = "Counter" + 1, "OptimisticLockField" = "OptimisticLockField" + 1
	where "OID" = new."WaitingRoom";
	
	-- set current entry number
	update "WaitingRoomEntry" 
	set "Number" = max_number, "OptimisticLockField" = "OptimisticLockField" + 1
	where "OID" = new."OID";

	return null;
End
$$;

alter function setwaitingroomentrynumber() owner to postgres;

