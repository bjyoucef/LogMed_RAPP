create function setitemcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Item"', 'Item');
	return null;
End
$$;

alter function setitemcode() owner to postgres;

