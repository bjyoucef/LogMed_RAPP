create function setmedicalactcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"MedicalAct"', 'MedicalAct');
	return null;
End
$$;

alter function setmedicalactcode() owner to postgres;

