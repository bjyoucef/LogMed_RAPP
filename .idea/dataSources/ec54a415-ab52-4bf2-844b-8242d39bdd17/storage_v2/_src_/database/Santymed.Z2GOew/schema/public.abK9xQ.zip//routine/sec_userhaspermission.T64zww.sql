create function sec_userhaspermission("userOid" integer, context text, "actionId" text, "permissionType" integer) returns boolean
    language plpgsql
as
$$
DECLARE isSuperAdmin boolean;
DECLARE permissionOid integer;
BEGIN
	isSuperAdmin = (
		SELECT "Role"."IsSuperAdmin"
		FROM  public."Role", public."RoleUser"
		WHERE "RoleUser"."Role" = "Role"."OID" AND "RoleUser"."User" = "userOid");

	IF(isSuperAdmin = true) THEN
		RETURN true;
	END IF;

	permissionOid = (
		SELECT "Permission"."OID"
		FROM public."Permission", public."User", public."RoleUser", public."Context"
		WHERE "Permission"."Context" = "Context"."OID" AND
		  "User"."OID" = "RoleUser"."User" AND
		  "RoleUser"."Role" = "Permission"."Role" AND
		  "User"."OID" = "userOid" AND 
		  "Context"."Name" = context AND 
		  ("actionId" is null or "Permission"."ActionId" = "actionId") AND 
		  "Permission"."Type" = "permissionType");
	
	IF(permissionOid > 0) THEN
		RETURN true;
	END IF;

	RETURN false;
END;$$;

alter function sec_userhaspermission(integer, text, text, integer) owner to postgres;

