create function setpaymentcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"Payment"', 'Payment');
	return null;
End
$$;

alter function setpaymentcode() owner to postgres;

