create function setmedicalreportcode() returns trigger
    language plpgsql
as
$$

BEGIN
	PERFORM setnextcode(new."OID", '"MedicalReport"', 'MedicalReport');
	return null;
End
$$;

alter function setmedicalreportcode() owner to postgres;

