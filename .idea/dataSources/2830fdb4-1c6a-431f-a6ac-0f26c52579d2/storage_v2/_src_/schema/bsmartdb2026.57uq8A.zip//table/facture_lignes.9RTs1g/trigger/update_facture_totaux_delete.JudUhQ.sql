create definer = root@localhost trigger update_facture_totaux_delete
    after delete
    on facture_lignes
    for each row
BEGIN
    DECLARE v_mode_paiement VARCHAR(20);
    DECLARE v_montant_paye_caisse DECIMAL(10,2);
    DECLARE v_total_ttc DECIMAL(10,2);
    DECLARE v_total_debours DECIMAL(10,2);
    DECLARE v_montant_base_timbre DECIMAL(10,2);
    DECLARE v_droit_timbre DECIMAL(10,2);
    
    UPDATE factures 
    SET 
        total_ht = (SELECT IFNULL(SUM(montant_ht), 0) 
                    FROM facture_lignes 
                    WHERE facture_id = OLD.facture_id AND est_debours = FALSE),
        total_tva_9 = (SELECT IFNULL(SUM(montant_tva), 0) 
                       FROM facture_lignes 
                       WHERE facture_id = OLD.facture_id AND taux_tva = 9),
        total_tva_19 = (SELECT IFNULL(SUM(montant_tva), 0) 
                        FROM facture_lignes 
                        WHERE facture_id = OLD.facture_id AND taux_tva = 19),
        total_tva = (SELECT IFNULL(SUM(montant_tva), 0) 
                     FROM facture_lignes 
                     WHERE facture_id = OLD.facture_id AND est_debours = FALSE),
        total_ttc = (SELECT IFNULL(SUM(montant_ttc), 0) 
                     FROM facture_lignes 
                     WHERE facture_id = OLD.facture_id AND est_debours = FALSE),
        total_debours = (SELECT IFNULL(SUM(montant_ht), 0) 
                         FROM facture_lignes 
                         WHERE facture_id = OLD.facture_id AND est_debours = TRUE)
    WHERE id = OLD.facture_id;
    
    SELECT mode_paiement, montant_paye_caisse, total_ttc, total_debours
    INTO v_mode_paiement, v_montant_paye_caisse, v_total_ttc, v_total_debours
    FROM factures 
    WHERE id = OLD.facture_id;
    
    -- LOGIQUE INTELLIGENTE
    IF v_montant_paye_caisse IS NOT NULL AND v_montant_paye_caisse > 0 THEN
        SET v_montant_base_timbre = v_montant_paye_caisse;
    ELSE
        SET v_montant_base_timbre = v_total_ttc + v_total_debours;
    END IF;
    
    SET v_droit_timbre = calculer_droit_timbre(v_montant_base_timbre, v_mode_paiement);
    
    UPDATE factures f
    SET droit_timbre = v_droit_timbre,
        total_net = f.total_ttc + f.total_debours + v_droit_timbre
    WHERE id = OLD.facture_id;
END;

