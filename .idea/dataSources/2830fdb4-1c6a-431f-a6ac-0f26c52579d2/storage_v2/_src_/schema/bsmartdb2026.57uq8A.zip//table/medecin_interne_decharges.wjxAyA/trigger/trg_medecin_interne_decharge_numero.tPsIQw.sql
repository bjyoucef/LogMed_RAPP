create definer = root@localhost trigger trg_medecin_interne_decharge_numero
    before insert
    on medecin_interne_decharges
    for each row
BEGIN
    IF NEW.numero_decharge IS NULL OR NEW.numero_decharge = '' THEN
        SET NEW.numero_decharge = generate_numero_decharge_medecin();
    END IF;
END;

