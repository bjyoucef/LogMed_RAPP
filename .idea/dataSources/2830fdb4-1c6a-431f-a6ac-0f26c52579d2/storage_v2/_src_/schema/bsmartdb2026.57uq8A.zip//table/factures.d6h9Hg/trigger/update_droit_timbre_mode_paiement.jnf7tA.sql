create definer = root@localhost trigger update_droit_timbre_mode_paiement
    before update
    on factures
    for each row
BEGIN
    DECLARE v_montant_base_timbre DECIMAL(10,2);
    DECLARE v_droit_timbre DECIMAL(10,2);
    
    -- Recalculer seulement si changement pertinent
    IF OLD.mode_paiement != NEW.mode_paiement OR 
       OLD.montant_paye_caisse != NEW.montant_paye_caisse OR
       OLD.montant_paye_caisse IS NULL AND NEW.montant_paye_caisse IS NOT NULL OR
       OLD.montant_paye_caisse IS NOT NULL AND NEW.montant_paye_caisse IS NULL THEN
        
        -- LOGIQUE INTELLIGENTE : Choisir la base de calcul
        IF NEW.montant_paye_caisse IS NOT NULL AND NEW.montant_paye_caisse > 0 THEN
            SET v_montant_base_timbre = NEW.montant_paye_caisse;
        ELSE
            SET v_montant_base_timbre = NEW.total_ttc + NEW.total_debours;
        END IF;
        
        -- Calcul du droit de timbre
        SET v_droit_timbre = calculer_droit_timbre(v_montant_base_timbre, NEW.mode_paiement);
        
        SET NEW.droit_timbre = v_droit_timbre;
        SET NEW.total_net = NEW.total_ttc + NEW.total_debours + v_droit_timbre;
    END IF;
END;

