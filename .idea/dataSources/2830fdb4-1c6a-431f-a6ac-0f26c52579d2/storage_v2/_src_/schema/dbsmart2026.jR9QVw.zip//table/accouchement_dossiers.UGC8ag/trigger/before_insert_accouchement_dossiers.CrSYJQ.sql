create definer = root@localhost trigger before_insert_accouchement_dossiers
    before insert
    on accouchement_dossiers
    for each row
BEGIN
    -- Initialisation des valeurs NULL
    IF NEW.prix_base IS NULL THEN SET NEW.prix_base = 0; END IF;
    IF NEW.prix_produits IS NULL THEN SET NEW.prix_produits = 0; END IF;
    IF NEW.prix_actes IS NULL THEN SET NEW.prix_actes = 0; END IF;
    IF NEW.prix_anesthesie IS NULL THEN SET NEW.prix_anesthesie = 0; END IF;
    IF NEW.prix_nuitees IS NULL THEN SET NEW.prix_nuitees = 0; END IF;
    IF NEW.prix_explorations IS NULL THEN SET NEW.prix_explorations = 0; END IF;
    IF NEW.supplement_gyneco IS NULL THEN SET NEW.supplement_gyneco = 0; END IF;
    IF NEW.montant_paye IS NULL THEN SET NEW.montant_paye = 0; END IF;
    IF NEW.mode_paiement IS NULL THEN SET NEW.mode_paiement = 'DIRECT'; END IF;

    -- Calcul du prix total
    SET NEW.prix_total = NEW.prix_base + NEW.prix_produits + NEW.prix_actes +
                         NEW.prix_anesthesie + NEW.prix_nuitees + NEW.prix_explorations;

    -- ✅ CALCUL DE LA BALANCE SELON MODE PAIEMENT
    IF NEW.est_gyneco_interne = 1 THEN
        -- INTERNE : balance = montant_paye - prix_total
        SET NEW.balance_medecin = NEW.montant_paye - NEW.prix_total;
    ELSE
        -- EXTERNE : dépend du mode de paiement
        IF NEW.mode_paiement = 'VIA_GYNECO' THEN
            -- Patient paie gynéco → Gynéco doit reverser part_clinique
            -- balance positive = gynéco doit à la clinique
            IF NEW.part_clinique IS NOT NULL THEN
                SET NEW.balance_medecin = NEW.part_clinique - NEW.montant_paye;
            ELSE
                SET NEW.balance_medecin = 0;
            END IF;
        ELSE
            -- DIRECT ou DIFFERE : Patient paie clinique → Clinique doit reverser part_gyneco
            -- balance négative = clinique doit au gynéco
            IF NEW.part_gyneco IS NOT NULL THEN
                SET NEW.balance_medecin = NEW.montant_paye - NEW.part_gyneco;
            ELSE
                SET NEW.balance_medecin = 0;
            END IF;
        END IF;
    END IF;

    -- ✅ CALCUL DU STATUT SELON MODE PAIEMENT
    IF NEW.est_gyneco_interne = 1 THEN
        -- INTERNE
        IF ABS(NEW.balance_medecin) < 0.01 THEN
            SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';
        ELSEIF NEW.balance_medecin > 0 THEN
            SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';
        ELSE
            SET NEW.statut_paiement = 'COMPLEMENT_PATIENT';
        END IF;
    ELSE
        -- EXTERNE
        IF NEW.mode_paiement = 'VIA_GYNECO' THEN
            -- Balance positive = gynéco doit
            IF ABS(NEW.balance_medecin) < 0.01 THEN
                SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';  -- Soldé
            ELSEIF NEW.balance_medecin > 0 THEN
                SET NEW.statut_paiement = 'GYNECO_DOIT_PAYER';
            ELSE
                SET NEW.statut_paiement = 'CLINIQUE_DOIT_PAYER';
            END IF;
        ELSE
            -- DIRECT/DIFFERE : Balance négative = clinique doit
            IF ABS(NEW.balance_medecin) < 0.01 THEN
                SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';  -- Soldé
            ELSEIF NEW.balance_medecin > 0 THEN
                SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';
            ELSE
                SET NEW.statut_paiement = 'CLINIQUE_DOIT_PAYER';
            END IF;
        END IF;
    END IF;
END;

