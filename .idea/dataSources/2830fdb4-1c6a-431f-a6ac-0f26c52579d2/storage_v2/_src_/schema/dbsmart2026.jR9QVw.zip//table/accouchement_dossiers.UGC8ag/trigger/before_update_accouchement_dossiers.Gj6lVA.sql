create definer = root@localhost trigger before_update_accouchement_dossiers
    before update
    on accouchement_dossiers
    for each row
BEGIN
    -- S'assurer que mode_paiement n'est pas NULL
    IF NEW.mode_paiement IS NULL THEN 
        SET NEW.mode_paiement = 'DIRECT'; 
    END IF;

    -- Calcul du prix total
    SET NEW.prix_total = NEW.prix_base + NEW.prix_produits + NEW.prix_actes +
                         NEW.prix_anesthesie + NEW.prix_nuitees + NEW.prix_explorations;

    -- ✅ CALCUL DE LA BALANCE SELON MODE PAIEMENT
    IF NEW.est_gyneco_interne = 1 THEN
        -- INTERNE
        SET NEW.balance_medecin = NEW.montant_paye - NEW.prix_total;
    ELSE
        -- EXTERNE : dépend du mode de paiement
        IF NEW.mode_paiement = 'VIA_GYNECO' THEN
            -- Gynéco doit reverser part_clinique
            SET NEW.balance_medecin = NEW.part_clinique - NEW.montant_paye;
        ELSE
            -- DIRECT/DIFFERE : Clinique doit reverser part_gyneco
            SET NEW.balance_medecin = NEW.montant_paye - NEW.part_gyneco;
        END IF;
    END IF;

    -- ✅ CALCUL DU STATUT SELON MODE PAIEMENT
    IF NEW.est_gyneco_interne = 1 THEN
        -- INTERNE
        IF ABS(NEW.balance_medecin) < 0.01 THEN
            SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';
        ELSEIF NEW.balance_medecin > 0 THEN
            SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';
        ELSE
            SET NEW.statut_paiement = 'COMPLEMENT_PATIENT';
        END IF;
    ELSE
        -- EXTERNE
        IF NEW.mode_paiement = 'VIA_GYNECO' THEN
            IF ABS(NEW.balance_medecin) < 0.01 THEN
                SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';
            ELSEIF NEW.balance_medecin > 0 THEN
                SET NEW.statut_paiement = 'GYNECO_DOIT_PAYER';
            ELSE
                SET NEW.statut_paiement = 'CLINIQUE_DOIT_PAYER';
            END IF;
        ELSE
            -- DIRECT/DIFFERE
            IF ABS(NEW.balance_medecin) < 0.01 THEN
                SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';
            ELSEIF NEW.balance_medecin > 0 THEN
                SET NEW.statut_paiement = 'SURPLUS_CLINIQUE';
            ELSE
                SET NEW.statut_paiement = 'CLINIQUE_DOIT_PAYER';
            END IF;
        END IF;
    END IF;
END;

