create definer = root@localhost trigger before_insert_paiement
    before insert
    on medecin_interne_paiements
    for each row
BEGIN
    IF NEW.numero_bon IS NULL THEN
        SET NEW.numero_bon = generate_numero_bon();
    END IF;
END;

