create
    definer = root@localhost procedure sp_recalculer_balance_dossier(IN p_id_dossier int, IN p_type_dossier varchar(20))
BEGIN
    DECLARE v_part DECIMAL(12,2);
    DECLARE v_enc_patient DECIMAL(12,2);
    DECLARE v_enc_medecin DECIMAL(12,2);
    DECLARE v_decaissement DECIMAL(12,2);
    DECLARE v_compensation DECIMAL(12,2);
    DECLARE v_balance DECIMAL(12,2);
    
    IF p_type_dossier = 'BLOC' THEN
        SELECT 
            dp.prix_total,
            COALESCE(SUM(ds.encaissement_patient), 0),
            COALESCE(SUM(ds.encaissement_doctor), 0),
            COALESCE(SUM(ds.decaissement_clinique), 0),
            COALESCE(SUM(ds.compensation), 0)
        INTO v_part, v_enc_patient, v_enc_medecin, v_decaissement, v_compensation
        FROM location_bloc_dossier_patient dp
        LEFT JOIN location_bloc_doctor_situations ds ON dp.id_dossier = ds.id_dossier
        WHERE dp.id_dossier = p_id_dossier
        GROUP BY dp.id_dossier;
    ELSE
        SELECT 
            a.part_gyneco,
            COALESCE(SUM(ags.encaissement_patient), 0),
            COALESCE(SUM(ags.encaissement_gyneco), 0),
            COALESCE(SUM(ags.decaissement_clinique), 0),
            COALESCE(SUM(ags.compensation), 0)
        INTO v_part, v_enc_patient, v_enc_medecin, v_decaissement, v_compensation
        FROM accouchement_dossiers a
        LEFT JOIN accouchement_gyneco_situations ags ON a.id_dossier = ags.id_dossier
        WHERE a.id_dossier = p_id_dossier
        GROUP BY a.id_dossier;
    END IF;
    
    SET v_balance = (v_enc_patient + v_enc_medecin + v_decaissement + v_compensation) - v_part;
    
    SELECT 
        v_part as part_medecin,
        v_enc_patient as encaissement_patient,
        v_enc_medecin as encaissement_medecin,
        v_decaissement as decaissement,
        v_compensation as compensation,
        v_balance as balance,
        CASE 
            WHEN v_balance > 0.01 THEN 'CLINIQUE_DOIT_PAYER'
            WHEN v_balance < -0.01 THEN 'MEDECIN_DOIT_PAYER'
            ELSE 'EQUILIBRE'
        END as statut;
END;

