create
    definer = root@localhost function generate_numero_decharge_medecin() returns varchar(50) deterministic
BEGIN
    DECLARE nouveau_numero VARCHAR(50);
    DECLARE compteur INT;
    DECLARE annee VARCHAR(4);
    DECLARE mois VARCHAR(2);
    DECLARE prefix VARCHAR(20);
    
    SET annee = YEAR(NOW());
    SET mois = LPAD(MONTH(NOW()), 2, '0');
    SET prefix = CONCAT('DMI-', annee, mois);
    
    -- Compter les décharges du mois
    SELECT COUNT(*) + 1 INTO compteur
    FROM medecin_interne_decharges
    WHERE numero_decharge LIKE CONCAT(prefix, '%');
    
    SET nouveau_numero = CONCAT(prefix, '-', LPAD(compteur, 4, '0'));
    
    RETURN nouveau_numero;
END;

