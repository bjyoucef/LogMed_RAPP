create definer = root@localhost trigger trg_kt_dossier_patient_after_insert
    after insert
    on kt_dossier_patient
    for each row
BEGIN
    INSERT INTO `kt_audit_dossier` (
        `id_dossier`,
        `id_status_facturation`,
        `montant_attendu_convention`,
        `montant_attendu_patient`,
        `montant_attendu_total`,
        `created_by`
    )
    SELECT 
        NEW.`id_dossier`,
        1, -- 'en_attente'
        COALESCE(NEW.`prix_dossier_convention`, 0),
        COALESCE(NEW.`prix_dossier_esp`, 0),
        COALESCE(NEW.`prix_dossier_convention`, 0) + COALESCE(NEW.`prix_dossier_esp`, 0),
        NEW.`created_by`;
END;

