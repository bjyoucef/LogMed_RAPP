create definer = root@localhost view v_hosp_financial_summary as
select `a`.`id_admission`                                                                         AS `id_admission`,
       `a`.`patient_nom`                                                                          AS `patient_nom`,
       `a`.`cout_total`                                                                           AS `cout_total`,
       coalesce(sum(`p`.`montant`), 0)                                                            AS `total_paye`,
       coalesce(sum(`p`.`avance`), 0)                                                             AS `total_avances`,
       coalesce(sum(`p`.`remboursement`), 0)                                                      AS `total_remboursements`,
       coalesce(sum(`p`.`montant`), 0) - coalesce(sum(`p`.`remboursement`), 0)                    AS `net_paye`,
       `a`.`cout_total` - coalesce(sum(`p`.`montant`), 0) + coalesce(sum(`p`.`remboursement`), 0) AS `reste_a_payer`,
       `a`.`statut`                                                                               AS `statut`
from (`dbsmartv7`.`hosp_admissions` `a` left join `dbsmartv7`.`hosp_paiements` `p`
      on (`a`.`id_admission` = `p`.`id_admission` and `p`.`est_annule` = 0 and
          `p`.`statut` in ('COMPLETE', 'PARTIEL', 'AVANCE')))
group by `a`.`id_admission`;

