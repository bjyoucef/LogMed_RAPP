create
    definer = root@localhost procedure sp_get_balance_dossier(IN p_id_dossier int, OUT p_balance decimal(10, 2),
                                                              OUT p_reste decimal(10, 2))
BEGIN
                       SELECT balance, reste_a_regler
                       INTO p_balance, p_reste
                       FROM v_situation_dossier
                       WHERE id_dossier = p_id_dossier;
                   END;

