create
    definer = root@localhost procedure sp_recalculer_prix_accouchement(IN p_id_dossier int)
BEGIN
    DECLARE v_prix_produits DECIMAL(12,2) DEFAULT 0;
    DECLARE v_prix_actes DECIMAL(12,2) DEFAULT 0;
    DECLARE v_prix_anesthesie DECIMAL(12,2) DEFAULT 0;
    DECLARE v_prix_explorations DECIMAL(12,2) DEFAULT 0;
    DECLARE v_prix_nuitees DECIMAL(12,2) DEFAULT 0;
    DECLARE v_prix_base DECIMAL(12,2) DEFAULT 0;
    DECLARE v_prix_total DECIMAL(12,2) DEFAULT 0;
    
    -- Calcul produits
    SELECT COALESCE(SUM(qte_utilisee * prix_unitaire), 0) INTO v_prix_produits
    FROM accouchement_dossier_produits WHERE id_dossier = p_id_dossier;
    
    -- Calcul actes
    SELECT COALESCE(SUM(qte_utilisee * prix_unitaire), 0) INTO v_prix_actes
    FROM accouchement_dossier_actes WHERE id_dossier = p_id_dossier;
    
    -- Calcul anesthésie
    SELECT COALESCE(SUM(honoraires_calcules), 0) INTO v_prix_anesthesie
    FROM accouchement_dossier_anesthesie WHERE id_dossier = p_id_dossier;
    
    -- Calcul explorations
    SELECT COALESCE(SUM(prix), 0) INTO v_prix_explorations
    FROM accouchement_dossier_explorations WHERE id_dossier = p_id_dossier;
    
    -- Calcul nuitées
    SELECT COALESCE(SUM(prix_total), 0) INTO v_prix_nuitees
    FROM accouchement_dossier_nuitees WHERE id_dossier = p_id_dossier;
    
    -- Prix de base
    SELECT prix_base INTO v_prix_base
    FROM accouchement_dossiers WHERE id_dossier = p_id_dossier;
    
    -- Prix total
    SET v_prix_total = v_prix_base + v_prix_produits + v_prix_actes 
                     + v_prix_anesthesie + v_prix_explorations + v_prix_nuitees;
    
    -- Mise à jour
    UPDATE accouchement_dossiers SET
        prix_produits = v_prix_produits,
        prix_actes = v_prix_actes,
        prix_anesthesie = v_prix_anesthesie,
        prix_explorations = v_prix_explorations,
        prix_nuitees = v_prix_nuitees,
        prix_total = v_prix_total
    WHERE id_dossier = p_id_dossier;
END;

