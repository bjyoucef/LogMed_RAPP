create
    definer = root@localhost procedure stats_medecin_complete(IN p_id_doctor int) reads sql data
BEGIN
    SELECT
        vsm.*,
        calcul_potentiel_compensation(p_id_doctor) AS potentiel_compensation
    FROM v_situation_medecin AS vsm
    WHERE vsm.id_doctor = p_id_doctor;

    SELECT
        type_operation,
        COUNT(*)               AS nombre_operations,
        SUM(montant)           AS total_montant,
        SUM(montant_paye)      AS total_paye,
        SUM(reste)             AS total_reste,
        AVG(montant)           AS montant_moyen
    FROM operations_financieres_medecin
    WHERE id_doctor = p_id_doctor
    GROUP BY type_operation;

    SELECT
        statut_paiement,
        COUNT(*)               AS nombre_dossiers,
        SUM(prix_total)        AS total_prix,
        SUM(reste_a_regler)    AS total_reste
    FROM v_situation_dossier
    WHERE id_doctor = p_id_doctor
    GROUP BY statut_paiement;
END;

