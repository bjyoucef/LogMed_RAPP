create definer = root@localhost view v_factures_resume as
select `f`.`id`                                                                AS `id`,
       `f`.`numero_facture`                                                    AS `numero_facture`,
       `f`.`type_facture`                                                      AS `type_facture`,
       `f`.`date_facture`                                                      AS `date_facture`,
       `f`.`date_echeance`                                                     AS `date_echeance`,
       `f`.`patient_nom`                                                       AS `patient_nom`,
       `f`.`patient_prenom`                                                    AS `patient_prenom`,
       `f`.`patient_adresse`                                                   AS `patient_adresse`,
       `f`.`patient_telephone`                                                 AS `patient_telephone`,
       `f`.`total_ht`                                                          AS `total_ht`,
       `f`.`total_tva_9`                                                       AS `total_tva_9`,
       `f`.`total_tva_19`                                                      AS `total_tva_19`,
       `f`.`total_tva`                                                         AS `total_tva`,
       `f`.`total_ttc`                                                         AS `total_ttc`,
       `f`.`total_debours`                                                     AS `total_debours`,
       `f`.`mode_paiement`                                                     AS `mode_paiement`,
       `f`.`droit_timbre`                                                      AS `droit_timbre`,
       `f`.`total_net`                                                         AS `total_net`,
       `f`.`remise_pourcentage`                                                AS `remise_pourcentage`,
       `f`.`remise_montant`                                                    AS `remise_montant`,
       `f`.`notes`                                                             AS `notes`,
       `f`.`conditions_paiement`                                               AS `conditions_paiement`,
       `f`.`statut`                                                            AS `statut`,
       `f`.`date_validation`                                                   AS `date_validation`,
       `f`.`valide_par`                                                        AS `valide_par`,
       `f`.`created_at`                                                        AS `created_at`,
       `f`.`updated_at`                                                        AS `updated_at`,
       `f`.`created_by`                                                        AS `created_by`,
       `f`.`patient_nif`                                                       AS `patient_nif`,
       `f`.`patient_rc`                                                        AS `patient_rc`,
       `f`.`patient_article`                                                   AS `patient_article`,
       `f`.`patient_raison_sociale`                                            AS `patient_raison_sociale`,
       `f`.`numero_cheque`                                                     AS `numero_cheque`,
       `f`.`date_annulation`                                                   AS `date_annulation`,
       `f`.`annule_par`                                                        AS `annule_par`,
       `f`.`montant_paye_caisse`                                               AS `montant_paye_caisse`,
       `f`.`proforma_origine_id`                                               AS `proforma_origine_id`,
       `f`.`proforma_origine_numero`                                           AS `proforma_origine_numero`,
       `f`.`est_transforme`                                                    AS `est_transforme`,
       `f`.`patient_oid_his`                                                   AS `patient_oid_his`,
       `f`.`patient_code_his`                                                  AS `patient_code_his`,
       `f`.`donnee_au_patient`                                                 AS `donnee_au_patient`,
       `f`.`date_remise_patient`                                               AS `date_remise_patient`,
       `f`.`remise_par`                                                        AS `remise_par`,
       concat(`f`.`patient_nom`, ' ', `f`.`patient_prenom`)                    AS `patient_complet`,
       count(`fl`.`id`)                                                        AS `nombre_lignes`,
       sum(case when `fl`.`taux_tva` = 9 then `fl`.`montant_ht` else 0 end)    AS `ht_tva_9`,
       sum(case when `fl`.`taux_tva` = 19 then `fl`.`montant_ht` else 0 end)   AS `ht_tva_19`,
       sum(case when `fl`.`est_debours` = 1 then `fl`.`montant_ht` else 0 end) AS `debours_calcule`,
       count(case when `fl`.`est_debours` = 1 then 1 end)                      AS `nombre_debours`,
       concat(`p`.`nom`, ' ', `p`.`prenom`)                                    AS `createur`,
       concat(`v`.`nom`, ' ', `v`.`prenom`)                                    AS `validateur`
from (((`dbsmartv7`.`factures` `f` left join `dbsmartv7`.`facture_lignes` `fl`
        on (`f`.`id` = `fl`.`facture_id`)) left join `dbsmartv7`.`personnel` `p`
       on (`f`.`created_by` = `p`.`id_personnel`)) left join `dbsmartv7`.`personnel` `v`
      on (`f`.`valide_par` = `v`.`id_personnel`))
group by `f`.`id`;

-- comment on column v_factures_resume.patient_nif not supported: Numéro d'identification fiscale du patient

-- comment on column v_factures_resume.patient_rc not supported: Registre de commerce du patient

-- comment on column v_factures_resume.patient_article not supported: Numéro d'article du patient

-- comment on column v_factures_resume.patient_raison_sociale not supported: Raison sociale si entreprise

-- comment on column v_factures_resume.numero_cheque not supported: Numéro de chèque si paiement par chèque

-- comment on column v_factures_resume.montant_paye_caisse not supported: Montant total payé en caisse (TTC avec timbre)

-- comment on column v_factures_resume.patient_oid_his not supported: OID du patient dans HIS

-- comment on column v_factures_resume.patient_code_his not supported: Code du patient dans HIS

-- comment on column v_factures_resume.donnee_au_patient not supported: Indique si la facture a été remise au patient

-- comment on column v_factures_resume.date_remise_patient not supported: Date de remise au patient

-- comment on column v_factures_resume.remise_par not supported: Personnel qui a remis la facture

