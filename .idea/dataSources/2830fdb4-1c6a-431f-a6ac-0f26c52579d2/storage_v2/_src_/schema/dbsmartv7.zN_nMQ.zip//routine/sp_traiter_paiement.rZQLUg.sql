create
    definer = root@localhost procedure sp_traiter_paiement(IN p_id_doctor int, IN p_montant decimal(10, 2),
                                                           IN p_type_operation varchar(20),
                                                           OUT p_montant_traite decimal(10, 2), OUT p_nb_dossiers int)
BEGIN
    DECLARE v_id_dossier INT;
    DECLARE v_reste DECIMAL(10,2);
    DECLARE v_montant_a_traiter DECIMAL(10,2);
    DECLARE v_montant_restant DECIMAL(10,2);
    DECLARE done INT DEFAULT FALSE;
    
    DECLARE cur_dossiers CURSOR FOR
        SELECT id_dossier, ABS(reste_a_regler) as reste
        FROM v_situation_dossier
        WHERE id_doctor = p_id_doctor
          AND (
              (p_type_operation = 'ENCAISSEMENT' AND reste_a_regler < 0) OR
              (p_type_operation = 'DECHARGE' AND reste_a_regler > 0)
          )
        ORDER BY location_date ASC;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    SET p_montant_traite = 0;
    SET p_nb_dossiers = 0;
    SET v_montant_restant = p_montant;
    
    OPEN cur_dossiers;
    
    read_loop: LOOP
        FETCH cur_dossiers INTO v_id_dossier, v_reste;
        
        IF done OR v_montant_restant <= 0 THEN
            LEAVE read_loop;
        END IF;
        
        SET v_montant_a_traiter = LEAST(v_montant_restant, v_reste);
        
        IF p_type_operation = 'ENCAISSEMENT' THEN
            INSERT INTO doctor_situations (
                id_doctor, id_dossier, encaissement_doctor, payment_date
            ) VALUES (
                p_id_doctor, v_id_dossier, v_montant_a_traiter, NOW()
            );
        ELSE
            INSERT INTO doctor_situations (
                id_doctor, id_dossier, decaissement_clinique, payment_date
            ) VALUES (
                p_id_doctor, v_id_dossier, v_montant_a_traiter, NOW()
            );
        END IF;
        
        SET p_montant_traite = p_montant_traite + v_montant_a_traiter;
        SET v_montant_restant = v_montant_restant - v_montant_a_traiter;
        SET p_nb_dossiers = p_nb_dossiers + 1;
    END LOOP;
    
    CLOSE cur_dossiers;
END;

