create definer = root@localhost trigger trg_kt_dossier_patient_after_update
    after update
    on kt_dossier_patient
    for each row
BEGIN
    -- Ne mettre à jour que si les montants ont changé
    IF OLD.`prix_dossier_convention` != NEW.`prix_dossier_convention` 
       OR OLD.`prix_dossier_esp` != NEW.`prix_dossier_esp` THEN
        
        UPDATE `kt_audit_dossier`
        SET `montant_attendu_convention` = COALESCE(NEW.`prix_dossier_convention`, 0),
            `montant_attendu_patient` = COALESCE(NEW.`prix_dossier_esp`, 0),
            `montant_attendu_total` = COALESCE(NEW.`prix_dossier_convention`, 0) + COALESCE(NEW.`prix_dossier_esp`, 0),
            `updated_by` = NEW.`updated_by`
        WHERE `id_dossier` = NEW.`id_dossier`;
    END IF;
END;

