create
    definer = root@localhost procedure sp_calculer_balance_dossier(IN p_id_dossier int, OUT p_balance decimal(10, 2))
BEGIN
    SELECT 
        COALESCE(SUM(decaissement_clinique), 0) - 
        COALESCE(SUM(encaissement_doctor), 0) + 
        COALESCE(SUM(compensation), 0)
    INTO p_balance
    FROM doctor_situations
    WHERE id_dossier = p_id_dossier;
END;

