create definer = root@localhost view v_kt_decharges_completes as
select `d`.`id_decharge`                                                                                            AS `id_decharge`,
       `d`.`id_doctor`                                                                                              AS `id_doctor`,
       `d`.`numero_decharge`                                                                                        AS `numero_decharge`,
       `d`.`date_decharge`                                                                                          AS `date_decharge`,
       `d`.`montant_total`                                                                                          AS `montant_total`,
       `d`.`montant_paye`                                                                                           AS `montant_paye`,
       `d`.`montant_restant`                                                                                        AS `montant_restant`,
       `d`.`statut`                                                                                                 AS `statut`,
       `d`.`observations`                                                                                           AS `observations`,
       `d`.`id_createur`                                                                                            AS `id_createur`,
       `d`.`date_creation`                                                                                          AS `date_creation`,
       `d`.`id_modificateur`                                                                                        AS `id_modificateur`,
       `d`.`date_modification`                                                                                      AS `date_modification`,
       `d`.`id_annulateur`                                                                                          AS `id_annulateur`,
       `d`.`date_annulation`                                                                                        AS `date_annulation`,
       `d`.`raison_annulation`                                                                                      AS `raison_annulation`,
       concat(`doc`.`first_name`, ' ', `doc`.`last_name`)                                                           AS `nom_medecin`,
       `spec`.`name_specialty`                                                                                      AS `name_specialty`,
       (select count(0)
        from `dbsmartv7`.`kt_decharges_dossiers` `dd`
        where `dd`.`id_decharge` = `d`.`id_decharge`)                                                               AS `nb_dossiers`,
       (select count(0)
        from `dbsmartv7`.`kt_decharges_tranches` `dt`
        where `dt`.`id_decharge` = `d`.`id_decharge`
          and `dt`.`statut` = 'ACTIVE')                                                                             AS `nb_tranches`,
       (select count(0)
        from `dbsmartv7`.`kt_decharges_tranches` `dt`
        where `dt`.`id_decharge` = `d`.`id_decharge`
          and `dt`.`statut` = 'ANNULEE')                                                                            AS `nb_tranches_annulees`,
       (select coalesce(sum(`dt`.`montant_tranche`), 0)
        from `dbsmartv7`.`kt_decharges_tranches` `dt`
        where `dt`.`id_decharge` = `d`.`id_decharge`
          and `dt`.`statut` = 'ANNULEE')                                                                            AS `montant_annule`
from ((`dbsmartv7`.`kt_decharges_paiement` `d` left join `dbsmartv7`.`doctors` `doc`
       on (`d`.`id_doctor` = `doc`.`id`)) left join `dbsmartv7`.`specialty` `spec`
      on (`doc`.`id_specialty` = `spec`.`id_specialty`));

