create definer = root@localhost view v_kt_bons_paiement_complet as
select `b`.`id_bon`                                                             AS `id_bon`,
       `b`.`id_dossier`                                                         AS `id_dossier`,
       `b`.`numero_bon`                                                         AS `numero_bon`,
       `b`.`montant_total`                                                      AS `montant_total`,
       `b`.`montant_a_payer`                                                    AS `montant_a_payer`,
       `b`.`montant_paye`                                                       AS `montant_paye`,
       `b`.`montant_restant`                                                    AS `montant_restant`,
       `b`.`type_bon`                                                           AS `type_bon`,
       `b`.`statut`                                                             AS `statut`,
       `b`.`nom_patient`                                                        AS `nom_patient`,
       `b`.`nom_assure`                                                         AS `nom_assure`,
       `b`.`details_json`                                                       AS `details_json`,
       `b`.`date_emission`                                                      AS `date_emission`,
       `b`.`date_echeance`                                                      AS `date_echeance`,
       `b`.`date_paiement_complet`                                              AS `date_paiement_complet`,
       `b`.`emis_par`                                                           AS `emis_par`,
       `b`.`encaisse_par`                                                       AS `encaisse_par`,
       `b`.`annule_par`                                                         AS `annule_par`,
       `b`.`raison_annulation`                                                  AS `raison_annulation`,
       `b`.`created_at`                                                         AS `created_at`,
       `b`.`updated_at`                                                         AS `updated_at`,
       `d`.`patient`                                                            AS `nom_patient_dossier`,
       `d`.`acte_date`                                                          AS `acte_date`,
       `d`.`prix_dossier_esp`                                                   AS `montant_attendu_dossier`,
       concat(`doc`.`first_name`, ' ', `doc`.`last_name`)                       AS `doctor_name`,
       concat(`p_emis`.`prenom`, ' ', `p_emis`.`nom`)                           AS `emis_par_nom`,
       concat(`p_encaisse`.`prenom`, ' ', `p_encaisse`.`nom`)                   AS `encaisse_par_nom`,
       concat(`p_annule`.`prenom`, ' ', `p_annule`.`nom`)                       AS `annule_par_nom`,
       (select count(0)
        from `dbsmartv7`.`kt_bons_paiement_paiements`
        where `dbsmartv7`.`kt_bons_paiement_paiements`.`id_bon` = `b`.`id_bon`) AS `nb_paiements`
from (((((`dbsmartv7`.`kt_bons_paiement_patient` `b` join `dbsmartv7`.`kt_dossier_patient` `d`
          on (`b`.`id_dossier` = `d`.`id_dossier`)) left join `dbsmartv7`.`doctors` `doc`
         on (`d`.`id_doctor` = `doc`.`id`)) left join `dbsmartv7`.`personnel` `p_emis`
        on (`b`.`emis_par` = `p_emis`.`id_personnel`)) left join `dbsmartv7`.`personnel` `p_encaisse`
       on (`b`.`encaisse_par` = `p_encaisse`.`id_personnel`)) left join `dbsmartv7`.`personnel` `p_annule`
      on (`b`.`annule_par` = `p_annule`.`id_personnel`));

