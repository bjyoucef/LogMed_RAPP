create
    definer = root@localhost function generate_numero_bon() returns varchar(50) deterministic
BEGIN
    DECLARE nouveau_numero VARCHAR(50);
    DECLARE compteur INT;
    DECLARE annee VARCHAR(4);
    DECLARE mois VARCHAR(2);
    
    SET annee = YEAR(NOW());
    SET mois = LPAD(MONTH(NOW()), 2, '0');
    
    -- Compter les bons du mois
    SELECT COUNT(*) + 1 INTO compteur
    FROM medecin_interne_paiements
    WHERE YEAR(date_paiement) = YEAR(NOW())
    AND MONTH(date_paiement) = MONTH(NOW());
    
    SET nouveau_numero = CONCAT('BON-', annee, mois, '-', LPAD(compteur, 5, '0'));
    
    RETURN nouveau_numero;
END;

