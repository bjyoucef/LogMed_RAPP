create definer = root@localhost trigger update_facture_totaux_update
    after update
    on facture_lignes
    for each row
BEGIN
    DECLARE v_total_ttc DECIMAL(10, 2);
    DECLARE v_total_debours DECIMAL(10, 2);
    DECLARE v_droit_timbre DECIMAL(10, 2);
    DECLARE v_mode_paiement VARCHAR(20);
    DECLARE v_total_facturable DECIMAL(10, 2);
    DECLARE v_tranches INT;
    
    UPDATE factures 
    SET 
        total_ht = (SELECT IFNULL(SUM(montant_ht), 0) 
                    FROM facture_lignes 
                    WHERE facture_id = NEW.facture_id AND est_debours = FALSE),
        total_tva_9 = (SELECT IFNULL(SUM(montant_tva), 0) 
                       FROM facture_lignes 
                       WHERE facture_id = NEW.facture_id AND taux_tva = 9),
        total_tva_19 = (SELECT IFNULL(SUM(montant_tva), 0) 
                        FROM facture_lignes 
                        WHERE facture_id = NEW.facture_id AND taux_tva = 19),
        total_tva = (SELECT IFNULL(SUM(montant_tva), 0) 
                     FROM facture_lignes 
                     WHERE facture_id = NEW.facture_id AND est_debours = FALSE),
        total_ttc = (SELECT IFNULL(SUM(montant_ttc), 0) 
                     FROM facture_lignes 
                     WHERE facture_id = NEW.facture_id AND est_debours = FALSE),
        total_debours = (SELECT IFNULL(SUM(montant_ht), 0) 
                         FROM facture_lignes 
                         WHERE facture_id = NEW.facture_id AND est_debours = TRUE)
    WHERE id = NEW.facture_id;
    
    SELECT total_ttc, total_debours, mode_paiement 
    INTO v_total_ttc, v_total_debours, v_mode_paiement
    FROM factures WHERE id = NEW.facture_id;
    
    SET v_total_facturable = v_total_ttc + v_total_debours;
    
    IF v_mode_paiement = 'especes' AND v_total_facturable > 300 THEN
        SET v_tranches = CEILING(v_total_facturable / 100) * 100;
        
        IF v_tranches <= 30000 THEN
            SET v_droit_timbre = v_tranches * 0.01;
        ELSEIF v_tranches <= 100000 THEN
            SET v_droit_timbre = v_tranches * 0.015;
        ELSE
            SET v_droit_timbre = v_tranches * 0.02;
        END IF;
        
        IF v_droit_timbre < 5 THEN
            SET v_droit_timbre = 5;
        END IF;
    ELSE
        SET v_droit_timbre = 0;
    END IF;
    
    UPDATE factures 
    SET droit_timbre = v_droit_timbre,
        total_net = v_total_ttc + v_total_debours + v_droit_timbre
    WHERE id = NEW.facture_id;
END;

