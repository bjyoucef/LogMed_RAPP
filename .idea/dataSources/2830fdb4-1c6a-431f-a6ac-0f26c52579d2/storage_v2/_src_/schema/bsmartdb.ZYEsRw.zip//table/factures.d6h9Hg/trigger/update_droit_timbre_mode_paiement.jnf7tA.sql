create definer = root@localhost trigger update_droit_timbre_mode_paiement
    before update
    on factures
    for each row
BEGIN
    DECLARE v_droit_timbre DECIMAL(10, 2);
    DECLARE v_total_facturable DECIMAL(10, 2);
    DECLARE v_tranches INT;
    
    -- Recalculer seulement si le mode de paiement a changé
    IF OLD.mode_paiement != NEW.mode_paiement OR 
       OLD.total_ttc != NEW.total_ttc OR 
       OLD.total_debours != NEW.total_debours THEN
        
        SET v_total_facturable = NEW.total_ttc + NEW.total_debours;
        
        IF NEW.mode_paiement = 'especes' AND v_total_facturable > 300 THEN
            SET v_tranches = CEILING(v_total_facturable / 100) * 100;
            
            IF v_tranches <= 30000 THEN
                SET v_droit_timbre = v_tranches * 0.01;
            ELSEIF v_tranches <= 100000 THEN
                SET v_droit_timbre = v_tranches * 0.015;
            ELSE
                SET v_droit_timbre = v_tranches * 0.02;
            END IF;
            
            IF v_droit_timbre < 5 THEN
                SET v_droit_timbre = 5;
            END IF;
        ELSE
            SET v_droit_timbre = 0;
        END IF;
        
        SET NEW.droit_timbre = v_droit_timbre;
        SET NEW.total_net = NEW.total_ttc + NEW.total_debours + v_droit_timbre;
    END IF;
END;

