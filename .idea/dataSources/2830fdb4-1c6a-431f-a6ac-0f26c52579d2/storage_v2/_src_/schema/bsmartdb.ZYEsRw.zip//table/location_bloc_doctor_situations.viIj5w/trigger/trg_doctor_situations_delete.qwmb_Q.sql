create definer = root@localhost trigger trg_doctor_situations_delete
    after delete
    on location_bloc_doctor_situations
    for each row
BEGIN
    INSERT INTO audit_doctor_situations (
        action, id_doctor_situations, id_doctor, id_dossier,
        encaissement_doctor, decaissement_clinique, compensation
    )
    VALUES (
        'DELETE', OLD.id_doctor_situations, OLD.id_doctor, OLD.id_dossier,
        OLD.encaissement_doctor, OLD.decaissement_clinique, OLD.compensation
    );
END;

