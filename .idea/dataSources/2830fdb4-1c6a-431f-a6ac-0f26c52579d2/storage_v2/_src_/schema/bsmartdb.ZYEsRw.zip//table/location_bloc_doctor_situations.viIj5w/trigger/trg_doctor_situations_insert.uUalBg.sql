create definer = root@localhost trigger trg_doctor_situations_insert
    after insert
    on location_bloc_doctor_situations
    for each row
BEGIN
    INSERT INTO audit_doctor_situations (
        action, id_doctor_situations, id_doctor, id_dossier,
        encaissement_doctor, decaissement_clinique, compensation
    )
    VALUES (
        'INSERT', NEW.id_doctor_situations, NEW.id_doctor, NEW.id_dossier,
        NEW.encaissement_doctor, NEW.decaissement_clinique, NEW.compensation
    );
END;

