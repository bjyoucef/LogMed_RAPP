create definer = root@localhost trigger update_facture_totaux
    after insert
    on facture_lignes
    for each row
BEGIN
    DECLARE v_total_ttc DECIMAL(10, 2);
    DECLARE v_total_debours DECIMAL(10, 2);
    DECLARE v_droit_timbre DECIMAL(10, 2);
    DECLARE v_mode_paiement VARCHAR(20);
    DECLARE v_total_facturable DECIMAL(10, 2);
    DECLARE v_tranches INT;
    
    -- Calculer les totaux (hors débours pour HT et TVA)
    UPDATE factures 
    SET 
        total_ht = (SELECT IFNULL(SUM(montant_ht), 0) 
                    FROM facture_lignes 
                    WHERE facture_id = NEW.facture_id AND est_debours = FALSE),
        total_tva_9 = (SELECT IFNULL(SUM(montant_tva), 0) 
                       FROM facture_lignes 
                       WHERE facture_id = NEW.facture_id AND taux_tva = 9),
        total_tva_19 = (SELECT IFNULL(SUM(montant_tva), 0) 
                        FROM facture_lignes 
                        WHERE facture_id = NEW.facture_id AND taux_tva = 19),
        total_tva = (SELECT IFNULL(SUM(montant_tva), 0) 
                     FROM facture_lignes 
                     WHERE facture_id = NEW.facture_id AND est_debours = FALSE),
        total_ttc = (SELECT IFNULL(SUM(montant_ttc), 0) 
                     FROM facture_lignes 
                     WHERE facture_id = NEW.facture_id AND est_debours = FALSE),
        total_debours = (SELECT IFNULL(SUM(montant_ht), 0) 
                         FROM facture_lignes 
                         WHERE facture_id = NEW.facture_id AND est_debours = TRUE)
    WHERE id = NEW.facture_id;
    
    -- Récupérer les valeurs pour le calcul du droit de timbre
    SELECT total_ttc, total_debours, mode_paiement 
    INTO v_total_ttc, v_total_debours, v_mode_paiement
    FROM factures WHERE id = NEW.facture_id;
    
    -- Total facturable = TTC + Débours (pour le calcul du droit de timbre)
    SET v_total_facturable = v_total_ttc + v_total_debours;
    
    -- Calculer le droit de timbre (uniquement pour paiement en espèces)
    -- Le droit de timbre s'applique sur le TOTAL incluant les débours
    IF v_mode_paiement = 'especes' AND v_total_facturable > 300 THEN
        -- Arrondir au multiple de 100 supérieur
        SET v_tranches = CEILING(v_total_facturable / 100) * 100;
        
        -- Appliquer le taux selon les tranches
        IF v_tranches <= 30000 THEN
            SET v_droit_timbre = v_tranches * 0.01;
        ELSEIF v_tranches <= 100000 THEN
            SET v_droit_timbre = v_tranches * 0.015;
        ELSE
            SET v_droit_timbre = v_tranches * 0.02;
        END IF;
        
        -- Minimum 5 DA
        IF v_droit_timbre < 5 THEN
            SET v_droit_timbre = 5;
        END IF;
    ELSE
        SET v_droit_timbre = 0;
    END IF;
    
    -- Mettre à jour le droit de timbre et le total net
    -- Total net = TTC + Débours + Droit de timbre
    UPDATE factures 
    SET droit_timbre = v_droit_timbre,
        total_net = v_total_ttc + v_total_debours + v_droit_timbre
    WHERE id = NEW.facture_id;
END;

